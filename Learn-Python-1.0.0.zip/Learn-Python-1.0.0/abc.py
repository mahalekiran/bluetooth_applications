# import function
# import flask
# result= function.greet("Kiran")
# print(result)