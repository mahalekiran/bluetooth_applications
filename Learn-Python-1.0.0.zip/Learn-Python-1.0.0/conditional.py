a=int(input("enter a number"))
if a < 0 :
    print("Negative digit")
elif a >= 0 :
    print("Whole number")
