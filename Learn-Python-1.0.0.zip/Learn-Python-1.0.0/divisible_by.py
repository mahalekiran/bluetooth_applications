num=int(input("Enter a number"))
if num%5 == 0 and num%7==0 :
    print("It is divisible by 5 and 7 both")
else:
    print("It is not divisible by 5 and 7")
