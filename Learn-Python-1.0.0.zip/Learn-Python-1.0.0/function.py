def greet(a):
    print("Hello "+a)

greet("Kiran")