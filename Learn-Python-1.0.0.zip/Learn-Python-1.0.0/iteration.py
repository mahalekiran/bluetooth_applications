num=[1,45,30,77,100,3, 5]
for j in num:
    if(j>5):
        print(str(j)+" Greater Than 5")
    elif (j==5):
        print(str(j)+" Equal to 5")
    else:
        print(str(j)+" Less than 5")