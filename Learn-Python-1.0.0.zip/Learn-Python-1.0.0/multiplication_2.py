num=int(input("Enter a number: "))
for j in range(1,11):
    print(num*j)