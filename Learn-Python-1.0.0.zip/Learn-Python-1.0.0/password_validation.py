enter=input("Enter the password: ")
correct="Kiran"
while(True):
    if correct==enter:
        print("Correct password")
        break
    else:
        print("Wrong password")
        break