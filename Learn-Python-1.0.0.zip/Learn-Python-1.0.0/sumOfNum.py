num=input("Enter a number")
sum=0
for j in str(num):
    sum+=int(j)
    print(j)
print("Sum of the entered digits:"+str(sum))