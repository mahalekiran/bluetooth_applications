str=input("Enter a value: ")
abc = set()
for i in str:
    abc.add(i)
print(abc)
